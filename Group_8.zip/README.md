## Pending Tasks

### File System:

1. **Colored Icons using a Library**

2. **Add "File" and "Folder" Buttons**

3. **Drag In and Out Functionality**

4. **Improved Color Scheme**

5. **Tooltips on Hover**
