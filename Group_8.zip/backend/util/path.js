const path = require('path');

//gives the root pathname
module.exports = path.dirname(require.main.filename);