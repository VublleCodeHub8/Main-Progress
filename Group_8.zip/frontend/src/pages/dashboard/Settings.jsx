import React from 'react';

const Settings = () => (
  <div>
    <h1 className="text-2xl font-bold mb-4">Settings</h1>
    {/* Add settings content */}
  </div>
);

export default Settings;