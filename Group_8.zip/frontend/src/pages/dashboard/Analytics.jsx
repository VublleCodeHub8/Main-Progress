import React from 'react';

function Analytics (){
    return (
  <div>
    <h1 className="text-2xl font-bold mb-4">Analytics</h1>
    {/* Add analytics content */}
  </div>
);
}

export default Analytics;