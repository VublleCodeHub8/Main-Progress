import React from 'react';

const Documentation = () => {
    return (
        <div>
            <h1>Documentation list page</h1>
        </div>
    );
};

export default Documentation;